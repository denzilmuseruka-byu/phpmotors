<!DOCTYPE html>
<html>
<head>
  <title>PMAMP</title>
  <link rel="stylesheet" href="style.css">
  <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet"> 
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&family=Uncial+Antiqua&display=swap" rel="stylesheet"> 

</head>
<body>

<main class="card">
  <div class="container">
    <h1 class="title center"><?php echo "Eat the cat!1"; ?></h1>
    <p class="subtitle center">PhpMyadmin with Apache, Mysql, Php</p>

    <div class="links center">
      <a class="button" href="http://pma.lvh.me">phpMyAdmin</a>
    </div>

    <p>Replace the contents in the <code>'www'</code> folder for your site
    to show up here.</p>

    <p>Connect to MySQL with the following credentials:</p>
    <pre>  
      $server = 'mysql';
      $dbname = 'dbase';
      $username = 'dbuser';
      $password = 'dbpass';
      $dsn = "mysql:host=$server;dbname=$dbname";
    </pre>

    <p>More info: <a
      href="https://github.com/ammonshepherd/pmamp">https://github.com/ammonshepherd/pmamp</a></p>
  </div>

</main>

</body>
</html> 
