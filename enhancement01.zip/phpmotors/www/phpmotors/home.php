<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Motors</title>
    <link rel="stylesheet" href="css/main.css">

</head>


<body class="index">

    <div class="main">
        <header>
            <img id="logo" src="/phpmotors/images/site/logo.png" alt="Company Logo">
            <a id="acctLink" href="/phpmotors/accounts/index.php/?action=login-page">My Account</a>
        </header>
        <nav>
            <ul>
                <li><a href="/phpmotors">Home</a></li>
                <li><a href="#">Classic</a></li>
                <li><a href="#">Sports</a></li>
                <li><a href="#">SUV</a></li>
                <li><a href="#">Trucks</a></li>
                <li><a href="#">Used</a></li>
            </ul>

        </nav>
        <main>
            <header>
                <h1>Welcome to PHP Motors!</h1>
                <div id="carDetails">
                    <h2>DMC Delorean</h2>
                    <div>3 Cup holders</div>
                    <div>Superman doors</div>
                    <div>Fuzzy dice!</div>
                    <button type="button" class="ownToday">Own Today</button>

                    <img src="../phpmotors/images/delorean.jpg" alt="Delorean">

                </div>
            </header>
            <div class="grid-container">

                <div class="grid-item">
                    <div id="col2">
                        <h3>Delorean Upgrades</h3>
                        <div id="minigrid">
                            <div class="upgrades">
                                <img src="images/upgrades/flux-cap.png" alt="Flux capacitor">
                                <a href="#">Flux Capacitor</a>
                            </div>
                            <div class="upgrades">
                                <img src="images/upgrades/flame.jpg" alt="Flames">
                                <a href="#">Flame Decals</a>

                            </div>
                            <div class="upgrades">
                                <img src="images/upgrades/bumper_sticker.jpg" alt="Bumper sticker">
                                <a href="#">Bumper Sticker</a>

                            </div>
                            <div class="upgrades">
                                <img src="images/upgrades/hub-cap.jpg" alt="Hub Cap">
                                <a href="#">Hub Caps</a>

                            </div>
                        </div>


                    </div>
                </div>
                <div class="grid-item">
                    <div id="col1">
                        <h3>DMC Delorean Reviews</h3>
                        <ul>
                            <li>"So fast it's almost like traveling in time." (4/5)</li>
                            <li>"Coolest ride on the road." (4/5)</li>
                            <li>"I'm feeling Marty McFly!" (5/5)</li>
                            <li>"The most futuristic ride of our day." (4.5/5)</li>
                            <li>"80s livin and I love it!" (5/5)</li>
                        </ul>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <hr>
            <p>&copy; PHP Motors, All rights reserved.</p>
            <p>All images are believed to be "Fair Use". Please notify the author if any are not and they will be removed.</p>
            <p id="bottom">Last Updated: <?php echo date("d M Y") ?></p>
        </footer>
    </div>

</body>

</html>