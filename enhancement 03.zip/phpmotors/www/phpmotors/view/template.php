<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Motors</title>
    <link rel="stylesheet" href="css/main.css">

</head>


<body class="index">

    <div class="main">
        <header>
            <img id="logo" src="/phpmotors/images/site/logo.png" alt="Company Logo">
            <a id="acctLink" href="/phpmotors/accounts/index.php/?action=login">My Account</a>
        </header>
        <nav>
            <ul>
                <li><a href="/phpmotors">Home</a></li>
                <li><a href="#">Classic</a></li>
                <li><a href="#">Sports</a></li>
                <li><a href="#">SUV</a></li>
                <li><a href="#">Trucks</a></li>
                <li><a href="#">Used</a></li>
            </ul>

        </nav>
        <main>
            <h1>Content Title Here</h1>
        </main>
        <footer>
            <hr>
            <p>&copy; PHP Motors, All rights reserved.</p>
            <p>All images are believed to be "Fair Use". Please notify the author if any are not and they will be removed.</p>
            <p id="bottom">Last Updated: <?php echo date("d M Y") ?></p>
        </footer>
    </div>

</body>

</html>