<?php

/*********************************************************
 * ACCOUNTS MODEL
 * ***************************************************** */

/************************************************************
 * site registration
 *************************************************  */
function regClient($clientFirstname, $clientLastname, $clientEmail, $clientPassword)
{
    $db = phpmotorsConnect();
    // The SQL statement
    $sql = 'INSERT INTO clients (clientFirstname, clientLastname,clientEmail, clientPassword)
     VALUES (:clientFirstname, :clientLastname, :clientEmail, :clientPassword)';
    // Create the prepared statement using the phpmotors connection
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':clientFirstname', $clientFirstname, PDO::PARAM_STR);
    $stmt->bindValue(':clientLastname', $clientLastname, PDO::PARAM_STR);
    $stmt->bindValue(':clientEmail', $clientEmail, PDO::PARAM_STR);
    $stmt->bindValue(':clientPassword', $clientPassword, PDO::PARAM_STR);
    // Insert the data
    $stmt->execute();
    $rowsChanged = $stmt->rowCount();
    $stmt->closeCursor();
    return $rowsChanged;
}

/* Check for existing email address */
function checkExistingEmail($clientEmail)
{
    $db = phpMotorsConnect();
    $sql = 'SELECT clientEmail FROM clients WHERE clientEmail = :email';
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':email', $clientEmail, PDO::PARAM_STR);
    $stmt->execute();
    $matchEmail = $stmt->fetch(PDO::FETCH_NUM);
    $stmt->closeCursor();

    # Actual return statments
    if (empty($matchEmail)) {
        return 0;
    } else {
        return 1;
    }
}

// Get client based on email address
function getClient($clientEmail)
{
    $db = phpmotorsConnect();
    $sql = 'SELECT clientId, clientFirstname, clientLastname, clientEmail, clientLevel, clientPassword FROM clients WHERE clientEmail = :clientEmail';
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':clientEmail', $clientEmail, PDO::PARAM_STR);
    $stmt->execute();
    $clientData = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $clientData;
}

/* Update client */
function updateClient($clientFirstname, $clientLastname, $clientEmail, $clientId) {	
	$db = phpMotorsConnect();
	$sql = 'UPDATE clients SET clientFirstname = :clientFirstname, clientLastname = :clientLastname, clientEmail = :clientEmail WHERE clientId = :clientId';	
	$stmt = $db -> prepare($sql);
	
	$stmt->bindValue(':clientFirstname', $clientFirstname, PDO::PARAM_STR);
    $stmt->bindValue(':clientLastname', $clientLastname, PDO::PARAM_STR);
    $stmt->bindValue(':clientEmail', $clientEmail, PDO::PARAM_STR);
    $stmt->bindValue(':clientId', $clientId, PDO::PARAM_INT);

	$stmt -> execute();
	$rowsChanged = $stmt -> rowCount();
	$stmt -> closeCursor();
	return $rowsChanged;
}
/* Update client password */
function updatePassword($clientId, $clientPassword) {
	
	$db = phpMotorsConnect();
	// 4 values here
	$sql = 'UPDATE clients SET clientPassword = :clientPassword WHERE clientId = :clientId';
	
	$stmt = $db -> prepare($sql);
	
	$stmt->bindValue(':clientPassword', $clientPassword, PDO::PARAM_STR);
    $stmt->bindValue(':clientId', $clientId, PDO::PARAM_INT);

	$stmt -> execute();
	$rowsChanged = $stmt -> rowCount();
	$stmt -> closeCursor();
	return $rowsChanged;
}