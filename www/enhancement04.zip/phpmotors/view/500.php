<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/phpmotors/css/main.css">
    <title>PHP Motors | 500 Server Error</title>
</head>

<body  class="index">
    <div id="wrapper">
        <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?>
        <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/navbar.php'; ?>
        <main>
            <h1>Server Error</h1>
            <p>Sorry, our server seems to be experiencing some technical difficulties. Please, check back later.</p>
        </main>
        <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?>
    </div>
    <script src="../js/script.js"></script>
</body>

</html>