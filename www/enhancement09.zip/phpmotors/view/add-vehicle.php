<?php
//Build a dropdown menu
$dropdown = '<select name="classificationId" id="classificationId">';
$dropdown .= "<option disabled hidden selected>Choose Car Classification</option>";
foreach ($classifications as $classification) {
	$dropdown .= "<option value='" . urlencode($classification['classificationId']) . "'";
	if (isset($classificationId)) {
		if ($classification['classificationId'] === $classificationId) {
			$dropdown .= ' selected ';
		}
	}
	$dropdown .= ">$classification[classificationName]</option>";
}
$dropdown .= '</select>';
?>


<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="stylesheet" href="/phpmotors/css/main.css">
	<title>Add Vehicle | PHP Motors</title>
</head>

<body>
	<?php if ($_SESSION['clientData']['clientLevel'] == 1) {
		header('Location: /phpmotors/index.php');
		exit;
	} ?>
	<div id="wrapper" class="main-container">
		<?php require_once '../snippets/header.php'; ?>
		<nav><?php echo $navList; ?></nav>
		<main>

			<?php
			if (isset($message)) {
				echo $message;
			}
			?>

			<form id="vehicles" method="post" action="/phpmotors/vehicles/index.php">
				<h1>Add Vehicle</h1>
				<p>* Note all Fields are Required.</p>
				<fieldset>
					<legend>Add information about a new vehicle here</legend>

					<?php
					echo $dropdown;
					?>

					<label for="make_id">Make * </label>
					<input type="text" id="make_id" name="invMake" placeholder="E.g.: Jeep" required <?php echo "value='$invMake'" ?>>

					<label for="model_id">Model *</label>
					<input type="text" id="model_id" name="invModel" placeholder="E.g.: Wrangler" required <?php echo "value='$invModel'"; ?>>


					<label for="description_id">Description *</label>
					<textarea id="description_id" name="invDescription" placeholder="E.g.: JW, is a series of compact and mid-size, four-wheel drive off-road SUVs... etc." rows="6" required><?php echo "$invDescription"; ?></textarea>


					<label for="image_id">Image Path * </label>
					<input type="text" id="image_id" name="invImage" required <?php echo "value='$invImage'"; ?>>


					<label for="thumbnail_id">Thumbnail Path * </label>
					<input type="text" id="thumbnail_id" name="invThumbnail" required <?php echo "value='$invThumbnail'"; ?>>


					<label for="price_id">Price *</label>
					<input type="text" id="price_id" name="invPrice" placeholder="E.g.: 28475.45" required pattern="([0-9]+(?:\.[0-9]*)?)" <?php echo "value='$invPrice'"; ?>>


					<label for="stock_id"># In Stock * </label>
					<input type="text" id="stock_id" name="invStock" placeholder="E.g. in units: 4" required pattern="(^\d{1,10}$)" <?php echo "value='$invStock'"; ?>>


					<label for="color_id">Color * </label>
					<input type="text" id="color_id" name="invColor" placeholder="E.g.: Blue" required <?php echo "value='$invColor'"; ?>>

					<!-- Button -->
					<input type="submit" id="submit_id" value="Add Vehicle" class="form-button">

					<!-- Trigger. Tells the controller what action we need it to process. -->
					<input type="hidden" name="action" value="addVehicle">
				</fieldset>
			</form>
		</main>
		<?php require_once  '../snippets/footer.php'; ?>
	</div>
	<script src="../js/script.js"></script>
</body>

</html>