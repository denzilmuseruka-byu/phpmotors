INSERT INTO phpmotors.clients (clientFirstname,clientLastname,clientEmail,clientPassword,comment) 
VALUE ('Tony','Stark','tony@starkent.com','Iam1ronM@n',"I am the real Ironman");

UPDATE phpmotors.clients
SET clientLevel = 3
WHERE  clientId = 1;

UPDATE phpmotors.inventory
SET
invDescription = replace(invDescription,"small interior","spacious interior")
WHERE invId = 12;

SELECT invModel,
	carclassification.classificationName
FROM phpmotors.inventory
	INNER JOIN phpmotors.carclassification ON inventory.classificationId = carclassification.classificationId
WHERE carclassification.classificationName = "SUV";


UPDATE phpmotors.inventory 
SET 
    invImage = CONCAT('/phpmotors', invImage),
    invThumbnail = CONCAT('/phpmotors', invThumbnail);