<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Login|PHP Motors</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="/phpmotors/css/main.css">
</head>

<body class="index">
	<div id="wrapper">
		<?php require_once '../snippets/header.php'; ?>
		<?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/navbar.php'; ?>
		<main>
			<?php if (isset($_SESSION['message'])) {
				echo $_SESSION['message'];
			}
			if (isset($message)) {
				echo $message;
			}
			?>
			<form action="/phpmotors/accounts/index.php" method="post">
				<h1>Sign In</h1>
				<div>
					<label for="clientEmail">Email</label>
					<input type="email" name="clientEmail" id="clientEmail" placeholder="Your Email" autofocus autocomplete="off" <?php echo "value='$clientEmail'"; ?> required>
				</div>
				<div>
					<label for="clientPassword">Password</label>
					<input type="password" name="clientPassword" id="clientPassword" placeholder="Your Password" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" autocomplete="off" required>
				</div>
				<div>
					<input type="submit" name="Submit" value="Sign-in" class="button">
					<input type="hidden" name="action" value="login">
				</div>
			</form>
			<a id='notamember' href="/phpmotors/accounts/?action=registration">Not a member yet?</a>
		</main>
		<?php require_once '../snippets/footer.php'; ?>
	</div>
</body>

</html>