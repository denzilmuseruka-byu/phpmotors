<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="favicon.png">
	<link rel="stylesheet" href="/phpmotors/css/main.css">
	<title>Registration | PHP Motors</title>
	<style>
		body {
			font-size: medium;
		}
	</style>
</head>

<body>

	<div id="wrapper">
		<?php require_once  '../snippets/header.php'; ?>
		<?php require_once  '../snippets/navbar.php'; ?>
		<main>

			<?php
			if (isset($message)) {
				echo $message;
			}
			?>
			<form id="registration" method="post" action="/phpmotors/accounts/index.php">
				<h1>Register</h1>
				<fieldset>
					<legend>Join Our Community</legend>

					<p>* Required fields.</p>

					<label for="fname">First Name*
						<input type="text" id="fname" name="clientFirstname" placeholder="John" required <?php if (isset($clientFirstname)) {
																												echo "value='$clientFirstname'";
																											} ?>>
					</label>

					<label for="lname">Last Name*
						<input type="text" id="lname" name="clientLastname" placeholder="Doe" required <?php if (isset($clientLastname)) {
																											echo "value='$clientLastname'";
																										} ?>>
					</label>

					<label for="email">Email*
						<input type="email" id="email" name="clientEmail" placeholder="example@mail.com" required <?php if (isset($clientEmail)) {
																														echo "value='$clientEmail'";
																													} ?>>
					</label>

					<label for="password">Password*
						<input type="password" id="password" name="clientPassword" placeholder="See password requirements" required pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$">
					</label>
					<!-- Button -->
					<input type="submit" id="submit_id" value="Submit" class="form-button">

					<!-- Trigger. Tells the controller what action we need it to process. -->
					<input type="hidden" name="action" value="register">
				</fieldset>
			</form>
		</main>
		<?php require_once  '../snippets/footer.php'; ?>
	</div>
	<script src="../js/script.js"></script>
</body>

</html>