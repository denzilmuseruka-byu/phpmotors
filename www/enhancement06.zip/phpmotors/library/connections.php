<?php


/*********************************************************************
 * PROXY CONNECTION TO THE PHPMOTORS DATABASE
 * 
 ***********************************************************************/
function phpmotorsConnect()
{
    $server = 'mysql';
    $dbname = 'phpmotors';
    $username = 'iClient';
    $password = 'K_@KmyEA0L!LWRyw';
    $dsn = "mysql:host=$server;dbname=$dbname";
    $options = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);

    try {
        $link = new PDO($dsn, $username, $password, $options);
        return $link;
    } catch (PDOException $e) {
       header('Location: /phpmotors/view/500.php');       
    }
}
phpmotorsConnect();
?>