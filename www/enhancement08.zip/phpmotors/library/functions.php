<?php
/********************************************************************
 * FUNCTIONS
 * ******************************************************************/
function checkPassword($clientPassword)
{
	$pattern = '/^(?=.*[[:digit:]])(?=.*[[:punct:]])(?=.*[A-Z])(?=.*[a-z])([^\s]){8,}$/';
	return preg_match($pattern, $clientPassword);
}
// Build the classifications select list 
function buildClassificationList($classifications){ 
    $classificationList = '<select name="classificationId" id="classificationList">'; 
    $classificationList .= "<option>Choose a Classification</option>"; 
    foreach ($classifications as $classification) { 
     $classificationList .= "<option value='$classification[classificationId]'>$classification[classificationName]</option>"; 
    } 
    $classificationList .= '</select>'; 
    return $classificationList; 
   }

   //build a display of vehicles within an unordered list.
   function buildVehiclesDisplay($vehicles){
    $dv = '<ul id="inv-display">';
    foreach ($vehicles as $vehicle) {
        $currency =  number_format($vehicle['invPrice']);
        $currency =  number_format($currency, 3, ',', '');
     $dv .= "<li><a href='?action=details&invId=$vehicle[invId]'>";
     $dv .= "<img src='$vehicle[invThumbnail]' alt='Image of $vehicle[invMake] $vehicle[invModel] on phpmotors.com'>";
     $dv .= '<hr>';
     $dv .= "<h2><a href='?action=details&invId=$vehicle[invId]'>$vehicle[invMake] $vehicle[invModel]</a></h2>";
     $dv .= "<span>$$currency</span>";
     $dv .= '</a></li>';
    }
    $dv .= '</ul>';
    return $dv;
   }
function buildVehicleByIdDisplay($vehicle) {
	foreach ($vehicle as $data) {
        $currency =  number_format($data['invPrice']);
        $currency =  number_format($currency, 3, ',', '');
		# Main Container
        $dv = "<h1>$data[invMake] $data[invModel]</h1>";

		$dv .= '<div class="vehicle-container">';
		$dv .= "<div class='vehicle-image'>";
		$dv .= "<img src='$data[invImage]' alt='Image of $data[invMake] $data[invModel]'>";
		$dv .= "<span class='vehicle-amount'>Price: $$currency</span>";
		$dv .= '</div>';
		$dv .= "<div class='vehicle-details'>";
		$dv .= "<div class='vehicle-description'><p>$data[invDescription]</p></div>";
		$dv .= "<div class='vehicle-color'>Color: $data[invColor]</div>";
		$dv .= "<div class='vehicle-instock'><p># in stock: $data[invStock]</p></div>";
		$dv .= '</div>';
	} 		
		
	$dv .= '</div>'; // Close main container
	return $dv; // Display Vehicles
}

















?>